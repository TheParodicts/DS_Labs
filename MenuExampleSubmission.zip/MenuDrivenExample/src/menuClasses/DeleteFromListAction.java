package menuClasses;

public class DeleteFromListAction implements Action {

	@Override
	public void execute(Object args) {
		// TODO Auto-generated method stub

	}

}
