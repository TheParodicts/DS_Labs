package treeInterfaces;

public interface Position<E> {
	E getElement(); 
}
