package classes;

public class SymmetricStringAnalyzer {
	private String s; 
	public SymmetricStringAnalyzer(String s) {
		this.s = s; 
	}
	
	/**
	 * Determines if the string s is symmetric
	 * @return true if it is; false, otherwise. 
	 */
	public boolean isValidContent() { 
		LLStack<Character> stack = new LLStack<Character>(); 
		for (int i=0; i < s.length(); i++) { 
			char c = s.charAt(i) ; 
			
			if (Character.isLetter(c)){
				//If c is a letter
			
			   if (Character.isUpperCase(c)) //if c is uppercase
				  stack.push(c); 
			   else if (stack.isEmpty())//else, if the stack is empty.
					 return false; 
				   else {//else, if the stack is not empty and c is lowercase
					 char t =stack.top(); 
					 if (t == Character.toUpperCase(c))
					   stack.pop();  
					 else 
					    return false; 
					}
			}
				else 
					return false; 
		} 
		if(stack.isEmpty())
		return true; 
		else return false;
	}
	
	public String toString() { 
		return s; 
	}

	public String parenthesizedExpression() 
	throws StringIsNotSymmetricException 
	{
		if(!isValidContent()) throw new StringIsNotSymmetricException("parenthesizedExpression(): string is not symmetric.");
		else{
			String balanced= "";
			for (int i=0; i < s.length(); i++){
				char c = s.charAt(i) ;
				if(Character.isUpperCase(c)){
					balanced= balanced + "<"+c+" ";
				}
				else balanced = balanced + c +"> ";
			}
			return balanced;
		}
	}

}
