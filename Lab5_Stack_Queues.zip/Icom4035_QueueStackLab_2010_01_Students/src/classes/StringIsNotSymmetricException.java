package classes;

public class StringIsNotSymmetricException extends RuntimeException {

	public StringIsNotSymmetricException() {
		// TODO Auto-generated constructor stub
	}

	public StringIsNotSymmetricException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public StringIsNotSymmetricException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public StringIsNotSymmetricException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

}
