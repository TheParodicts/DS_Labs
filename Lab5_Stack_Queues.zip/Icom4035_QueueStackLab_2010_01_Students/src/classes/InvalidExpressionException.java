package classes;

public class InvalidExpressionException extends RuntimeException {

	public InvalidExpressionException() {
		// TODO Auto-generated constructor stub
	}

	public InvalidExpressionException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public InvalidExpressionException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public InvalidExpressionException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}
