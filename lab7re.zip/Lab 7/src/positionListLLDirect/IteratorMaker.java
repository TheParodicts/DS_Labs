package positionListLLDirect;

import java.util.Iterator;

import positionInterfaces.PositionList;
import positionListLLDirect.PositionListElementsBackwardIterator;

public class IteratorMaker<E> implements  PositionListIteratorMaker<E> {
	int type;
	
	public IteratorMaker(int type){
		this.type = type;
	}
	@Override
	public Iterator<E> makeIterator(PositionList<E> pl) {
		Iterator<E> temp = null;
		switch(type){
		default : temp = new PositionListElementsIterator(pl);
		case 0:  temp = new PositionListElementsIterator(pl);
		
		case 1: temp = new PositionListElementsBackwardIterator<E>(pl);
	}
		return temp;}

}
