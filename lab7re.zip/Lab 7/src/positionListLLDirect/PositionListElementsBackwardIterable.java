package positionListLLDirect;

import java.util.Iterator;

import positionInterfaces.PositionList;

public class PositionListElementsBackwardIterable<T> implements Iterable<T> {
	PositionList<T> in;
	
	public PositionListElementsBackwardIterable(PositionList<T>in){
		this.in = in;
	}
	@Override
	public Iterator<T> iterator() {
		return new PositionListElementsBackwardIterator<T>(in);
	}

	
}
