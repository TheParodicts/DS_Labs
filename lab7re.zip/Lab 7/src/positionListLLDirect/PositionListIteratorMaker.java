package positionListLLDirect;

import java.util.Iterator;

import positionInterfaces.PositionList;
import positionListLLDirect.PositionListElementsBackwardIterator;


public interface PositionListIteratorMaker<E> { 
    Iterator<E> makeIterator(PositionList<E> pl); 
} 

