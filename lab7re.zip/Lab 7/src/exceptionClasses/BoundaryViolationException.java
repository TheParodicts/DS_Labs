package exceptionClasses;

public class BoundaryViolationException extends RuntimeException {

	public BoundaryViolationException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BoundaryViolationException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public BoundaryViolationException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public BoundaryViolationException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
