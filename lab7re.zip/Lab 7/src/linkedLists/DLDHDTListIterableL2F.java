package linkedLists;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class DLDHDTListIterableL2F<E> extends DLDHDTList<E> 
									  implements Iterable<E> 
{
	public Iterator<E> iterator() {
		return new LLIteratorF2L<E>(this);
	}

	private static class LLIteratorF2L<E> 
	implements Iterator<E> 
	{ 
		private LinkedList<E> theList;   // the list to iterate over
		private int index;
		private Node<E> current; 
		private boolean hasMoreElements; 

		public LLIteratorF2L(LinkedList<E> list) {
			theList = list; 
			current = theList.getLastNode();
			index = theList.length();
			hasMoreElements=true;
		}

		public boolean hasNext() {
			return hasMoreElements; 
		}

		public E next() throws NoSuchElementException {
			if (!hasNext())
				throw new 
					NoSuchElementException("No more elements to iterate over."); 
			
			index--;
			hasMoreElements = (index>1);
			current = theList.getNodeBefore(current);
			return theList.getNodeAfter(current).getElement();
		}

		public void remove() throws UnsupportedOperationException 
		{
			throw new UnsupportedOperationException("Remove is not implemented.");

		}
	}

}
