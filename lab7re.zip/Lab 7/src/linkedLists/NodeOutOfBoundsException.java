package linkedLists;

public class NodeOutOfBoundsException extends RuntimeException {

	public NodeOutOfBoundsException() {
		// TODO Auto-generated constructor stub
	}

	public NodeOutOfBoundsException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public NodeOutOfBoundsException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public NodeOutOfBoundsException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

}
