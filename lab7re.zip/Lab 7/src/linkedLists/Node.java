package linkedLists;

public interface Node<E> {
	public E getElement();
	public void setElement(E data);
}
