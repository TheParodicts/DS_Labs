package positionInterfaces;

public interface Position<T> {
	T element(); 
}
