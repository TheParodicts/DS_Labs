package testers;

import queue.ArrayQueue;
import queue.Job;
import queue.SLLQueue;
import queue.ServingClass;

public class Simulation {
	public static void main(String[] args){
		ServingClass serving = new ServingClass();
		//To access csv files, write the file directory in path. Code is made to work with
		//files named sequentially (input1, input2, input3, etc.)
		String path = "C:/Users/brian/workspace/Lab 6/L6_QueueLab_2017 Student/jobinput";//the number is parsed later on.
		String csv = ".csv";
		
		SLLQueue<Job> inputQueue = new SLLQueue<Job>();
		SLLQueue<Job> processingQueue = new SLLQueue<Job>();
		SLLQueue<Job> terminatedJobs = new SLLQueue<Job>();
		float averageTime;
		
		//Simulations with SLLQueues
		
		System.out.println("Now testing Simulation with SLLQueues:\n");
		//first simulation
		for(int i=1; i<7;i++){
		serving.readCSV((path+Integer.toString(i)+csv),inputQueue);
		 averageTime= serving.serve(processingQueue, inputQueue, terminatedJobs);
		System.out.println("Average Time in System is: "+averageTime);
		}
		
		//Simulations with ArrayQueues
		
		System.out.println("\nNow testing Simulation with ArrayQueues:\n");
		
		ArrayQueue<Job> in= new ArrayQueue<Job>();
		ArrayQueue<Job> processing= new ArrayQueue<Job>();
		ArrayQueue<Job> out= new ArrayQueue<Job>();
		
		//First Simulation
		for(int i = 1; i<7; i++){
		serving.readCSV(path+Integer.toString(i)+csv,in);
		averageTime = serving.serve(processing, in, out);
		System.out.println("Average Time in System is: "+averageTime);
		}
		
	}
}
