package queue;

import java.lang.reflect.Array;

public class ArrayQueue<E> implements Queue<E> {
	private final static int INITCAP = 4; 
	private E[] elements;
	private int size;
	private int first;
	//JUST FOR TESTING
	
	@SuppressWarnings("unchecked")
	public ArrayQueue(){
		elements = (E[]) new Object[INITCAP];
		size=0;
		first=0;
	}
		@Override
		public void showReverse() { 
		    if (size == 0)
			   System.out.println("Queue is empty."); 
			else
			   recSR(first);
	    } 
	    private void recSR(int f) { 
			if (elements[f] != null) { 
			   recSR(f+1); 
			   System.out.println(elements[f]); 
		     } 
	    }
		@Override
		public int size() {
			return size;
		}
		@Override
		public boolean isEmpty() {
			return (size == 0);
		}
		@Override
		public E first() {
			if(isEmpty()) return null;
			return elements[first];
		}
		@Override
		public E dequeue() {
			if(size==0) return null;
			E temp = elements[first];
			elements[first]= null;
			size--;
			first = (first+1)%elements.length;
			return temp;
		}
		@Override
		public void enqueue(E e) {
			if (size == elements.length)   // check capacity, double it if needed
				changeCapacity(2*size); 
		elements[((first+size)%elements.length)]=e;
		size++;	
		} 

		private void changeCapacity(int newCapacity) { 
			// PRE: newCapacity >= size
			E[] temp = (E[]) new Object[newCapacity]; 
			for (int i=0; i<size; i++) {
				int srcIndex = (first + i) % elements.length; 
				temp[i] = elements[srcIndex]; 
				elements[srcIndex] = null; 
			} 
			elements = temp; 
			first = 0; 
		}

}
