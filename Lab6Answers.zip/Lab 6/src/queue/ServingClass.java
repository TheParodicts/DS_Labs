package queue;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class ServingClass {
	
	public ServingClass(){
		return;
	}
	
	//Any class properly implementing the Queue interface may be used
	public float serve(Queue<Job> processingQueue, Queue<Job> arrivalQueue, Queue<Job> terminatedJobs){
		int time = 0;
		int queueID = 1;
		
		while(!processingQueue.isEmpty()||!arrivalQueue.isEmpty()){
			if(!processingQueue.isEmpty()){
				processingQueue.first().advance();
				if(processingQueue.first().getServeTime()==0){
					processingQueue.first().setOutTime(time-processingQueue.first().getArrivalTime());
					terminatedJobs.enqueue(processingQueue.first());
					processingQueue.dequeue();
				}
				else{
					processingQueue.enqueue(processingQueue.first());
					processingQueue.dequeue();
				}
			}
			if(!arrivalQueue.isEmpty()&&arrivalQueue.first().getArrivalTime()==time){
				arrivalQueue.first().setID(queueID);
				queueID++;
				processingQueue.enqueue(arrivalQueue.first());
				arrivalQueue.dequeue();
			}
			time++;
		}
		float avTime;
		float sum=0;
		float jobs=0;
		
		while(!terminatedJobs.isEmpty()){
			sum+= terminatedJobs.first().getOutTime();
			terminatedJobs.dequeue();
			jobs++;
		}
		
		avTime=sum/jobs;
		return avTime;
	}
	
	
	
	public void readCSV(String fileDir, Queue<Job> queue){
		Queue<Job> tempList = queue;
		 BufferedReader br = null;
	        String line = "";
	        String cvsSplitBy = ",";
	        String[] jobs= new String[3];
	        Job job;
	        int id =1;
	        try {
	            br = new BufferedReader(new FileReader(fileDir));
	            while ((line = br.readLine()) != null) {
	                // use comma as separator
	              jobs = line.split(cvsSplitBy);
	              job = new Job(Integer.parseInt(jobs[0]),
            			  Integer.parseInt(jobs[1]));
	              job.setID(id);
	              tempList.enqueue(job);
	              id++;
	       	            }

	        } catch (FileNotFoundException e) {
	            e.printStackTrace();
	        } catch (IOException e) {
	            e.printStackTrace();
	        } finally {
	            if (br != null) {
	                try {
	                    br.close();
	                } catch (IOException e) {
	                    e.printStackTrace();
	                }
	            }
	        }
	}
	

	
	

}
