package queue;


public class SLLQueue<E> implements Queue<E> {
	private static class Node<E> {   // Inner class for nodes. 
		private E element; 
		private Node<E> next; 
		
		public Node(E e){
			element = e;
			next = null;
		}
		
		public Node(){
			element = null;
			next = null;
		}
		
		public Node(E e, Node<E> next){
			element = e;
			this.next = next;
		}
		
		public E getElement(){
			return element;
		}
		
		public Node<E> getNext(){
			return next;
		}
		
		public void setElement(E e){
			element = e;
		}
		
		public void setNext(Node<E> next){
			this.next=next;
		}
	}	
	private Node<E> first, last;   // references to first and last node
	private int size; 
	
	public SLLQueue() {           // initializes instance as empty queue
		first = last = null; 
		size = 0; 
	}
	public int size() {
		return size;
	}
	public boolean isEmpty() {
		return size == 0;
	}
	public E first() {
		if (isEmpty()) return null;
		return first.getElement(); 
	}
	public E dequeue() {
		if (isEmpty()) return null;		
		else{
			E temp = first.getElement();
			first.setElement(null);
			first=first.getNext();
			size--;
			return temp;
		}
	}
	public void enqueue(E e) {
		if (size == 0) 
			first = last = new Node<E>(e); 
		else { 
		last.setNext(new Node(e));
		last=last.getNext();
		}
		size++; 
	}


	//JUST FOR TESTING
	@Override
	public void showReverse() { 
	    if (size == 0)
		   System.out.println("Queue is empty."); 
		else
		   recSR(first);
    } 
    private void recSR(Node<E> f) { 
		if (f != null) { 
		   recSR(f.getNext()); 
		   System.out.println(f.getElement()); 
	     } 
    } 

}
