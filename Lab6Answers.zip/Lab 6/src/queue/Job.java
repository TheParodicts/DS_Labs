package queue;

public class Job {
private int ID;
private int arrivalTime;
private int serveTime;
private int outTime;

public Job( int arrivalTime, int serveTime){
	this.arrivalTime=arrivalTime;
	this.serveTime=serveTime;
}

public int getID(){
	return ID;
}

public int getArrivalTime(){
	return arrivalTime;
}

public int getServeTime(){
	return serveTime;
}

public void advance(){
	serveTime--;
}

public void setID(int id){
	ID=id;
}

public int getOutTime(){
	return outTime;
}

public void setOutTime(int out){
	outTime = out;
}

}
